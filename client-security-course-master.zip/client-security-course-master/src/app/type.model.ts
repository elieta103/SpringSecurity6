export class MyType{

    constructor(public msj: string = "loans"){}

}